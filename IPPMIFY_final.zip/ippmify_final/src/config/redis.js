const Redis = require('ioredis');

// Conexao com o Redis (Upstash)
// rediss:// ja usa TLS automaticamente — nao precisa de tls:{}
const redisUrl = process.env.REDIS_URL || '';
const tlsOptions = redisUrl.startsWith('rediss://') ? { tls: { rejectUnauthorized: false } } : {};

const redis = new Redis(redisUrl, {
  ...tlsOptions,
  maxRetriesPerRequest: 1,
  lazyConnect: true,
  connectTimeout: 8000,
  enableOfflineQueue: false,
});

redis.on('connect', () => {
  console.log('[Redis] Conectado ao Upstash Redis');
});

redis.on('error', (err) => {
  // Nao crasha o servidor se Redis falhar
  console.error('[Redis] Erro de conexao (nao critico):', err.message);
});

// Funcoes helper

// Salvar com tempo de expiracao (em segundos)
const setEx = async (key, value, ttlSeconds) => {
  return redis.setex(key, ttlSeconds, JSON.stringify(value));
};

// Buscar valor
const get = async (key) => {
  const value = await redis.get(key);
  if (!value) return null;
  try {
    return JSON.parse(value);
  } catch {
    return value;
  }
};

// Deletar chave
const del = async (key) => {
  return redis.del(key);
};

// Verificar se chave 